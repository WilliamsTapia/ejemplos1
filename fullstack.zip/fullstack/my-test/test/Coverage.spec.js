describe('Coverage example', () => {
  it('returns active when enabled', () => {
    expect(window.coverageExample(true)).toBe('active');
  });

  it('returns inactive when disabled', () => {
    expect(window.coverageExample(false)).toBe('inactive');
  });
});