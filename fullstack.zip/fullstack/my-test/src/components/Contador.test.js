import { fireEvent, render, screen } from '@testing-library/react';
import Contador from './Contador';

test('incrementa el contador cuando se hace clic', () => {
  render(<Contador />);
  fireEvent.click(screen.getByText('Incrementar'));

  expect(screen.getByText('Contador: 1')).toBeInTheDocument();
});