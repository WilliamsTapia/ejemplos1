import { fireEvent, render } from '@testing-library/react';
import Formulario from './Formulario';

test('llama a onSubmit cuando se envía el formulario', () => {
  const onSubmit = jest.fn();
  const { getByText } = render(<Formulario onSubmit={onSubmit} />);

  fireEvent.click(getByText('Enviar'));
  expect(onSubmit).toHaveBeenCalled();
});