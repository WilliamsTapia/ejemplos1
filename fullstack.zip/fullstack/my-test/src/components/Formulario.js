function Formulario({ onSubmit }) {
  function handleSubmit(event) {
    event.preventDefault();
    onSubmit(event);
  }

  return (
    <form onSubmit={handleSubmit}>
      <button type="submit">Enviar</button>
    </form>
  );
}

export default Formulario;