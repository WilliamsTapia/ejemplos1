import { render, screen } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'jest-axe';
import { performance } from 'perf_hooks';
import MiComponente from './MiComponente';

expect.extend(toHaveNoViolations);

test('renderiza correctamente', () => {
  render(<MiComponente />);
  expect(screen.getByText('Hola Mundo')).toBeInTheDocument();
});

test('renderiza rápidamente', () => {
  const start = performance.now();
  render(<MiComponente />);
  const elapsed = performance.now() - start;

  expect(elapsed).toBeLessThan(100);
});

test('no tiene violaciones de accesibilidad', async () => {
  const { container } = render(<MiComponente />);
  const results = await axe(container);

  expect(results).toHaveNoViolations();
});