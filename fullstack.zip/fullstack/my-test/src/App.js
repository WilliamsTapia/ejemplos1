import logo from './logo.svg';
import './App.css';
import Contador from './components/Contador.js';
import Formulario from './components/Formulario.js';
import MiComponente from './components/MiComponente.js';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Contador/>
		<Formulario/>
		<MiComponente/>
      </header>
    </div>
  );
}

export default App;
