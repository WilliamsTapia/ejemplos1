import axios from 'axios';
import { fetchDatos } from './fetchDatos';

jest.mock('axios');

beforeEach(() => {
  jest.clearAllMocks();
});

test('fetches datos exitosamente', async () => {
  const datos = { id: 1, nombre: 'Test' };
  axios.get.mockResolvedValue({ data: datos });

  await expect(fetchDatos()).resolves.toEqual(datos);
  expect(axios.get).toHaveBeenCalledWith('/api/datos');
});

test('maneja errores de API correctamente', async () => {
  axios.get.mockRejectedValue(new Error('API Error'));

  await expect(fetchDatos()).rejects.toThrow('API Error');
});