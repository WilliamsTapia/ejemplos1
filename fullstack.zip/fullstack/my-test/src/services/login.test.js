import axios from 'axios';
import { login } from './login';

jest.mock('axios');

test('realiza login correctamente', async () => {
  axios.post.mockResolvedValue({ data: { success: true } });

  await expect(login('usuario', 'secreto')).resolves.toBe(true);
  expect(axios.post).toHaveBeenCalledWith('/api/login', {
    username: 'usuario',
    password: 'secreto',
  });
});