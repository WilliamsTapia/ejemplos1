import axios from 'axios';

/**
 * Inicia sesión con la API y devuelve si las credenciales fueron aceptadas.
 * @param {string} username - Nombre de usuario.
 * @param {string} password - Contraseña.
 * @returns {Promise<boolean>} true cuando el inicio de sesión es exitoso.
 */
export async function login(username, password) {
  const response = await axios.post('/api/login', { username, password });
  return response.data.success;
}