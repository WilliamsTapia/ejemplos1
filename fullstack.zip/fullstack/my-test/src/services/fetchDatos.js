import axios from 'axios';

export async function fetchDatos(url = '/api/datos') {
  const response = await axios.get(url);
  return response.data;
}