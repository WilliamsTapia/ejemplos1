import { useState } from 'react';

function useContador() {
  const [contador, setContador] = useState(0);

  function incrementar() {
    setContador((valor) => valor + 1);
  }

  return { contador, incrementar };
}

export default useContador;