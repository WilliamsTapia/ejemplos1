window.coverageExample = function (enabled) {
  if (enabled) {
    return 'active';
  }

  return 'inactive';
};