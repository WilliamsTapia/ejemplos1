module.exports = function (config) {
  config.set({
    frameworks: ['jasmine'],
    files: ['src/karma/**/*.js', 'test/**/*.spec.js'],
    preprocessors: {
      'src/karma/**/*.js': ['coverage'],
    },
    reporters: ['progress', 'coverage'],
    coverageReporter: {
      type: 'html',
      dir: 'coverage/',
    },
    browsers: ['ChromeHeadless'],
    singleRun: true,
    concurrency: 2,
  });
};