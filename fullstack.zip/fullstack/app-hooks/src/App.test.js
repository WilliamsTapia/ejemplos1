import { render, screen } from '@testing-library/react';
import App from './App';

test('renders the hooks guide', () => {
  render(<App />);
  expect(screen.getByText(/La URL también/i)).toBeInTheDocument();
  expect(screen.getAllByText('useParams')).toHaveLength(2);
});
