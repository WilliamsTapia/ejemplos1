import { createContext, useContext, useEffect, useState } from 'react';
import { BrowserRouter, Link, NavLink, Route, Routes, useLocation, useParams, useSearchParams } from 'react-router-dom';
import './App.css';

const ReaderContext = createContext();

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="curso/:cursoId" element={<ParamsExample />} />
          <Route path="ubicacion" element={<LocationExample />} />
          <Route path="buscar" element={<SearchParamsExample />} />
          <Route path="contexto" element={<ContextExample />} />
          <Route path="efecto" element={<EffectExample />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

function Layout() {
  const location = useLocation();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link className="brand" to="/"><span className="brand-mark">{ }</span>Hooks en ruta</Link>
        <nav className="nav-links" aria-label="Ejemplos de hooks">
          <NavLink to="/curso/react">useParams</NavLink>
          <NavLink to="/ubicacion">useLocation</NavLink>
          <NavLink to="/buscar">useSearchParams</NavLink>
          <NavLink to="/contexto">useContext</NavLink>
          <NavLink to="/efecto">useEffect</NavLink>
        </nav>
      </header>
      <main className="page-content">
        <div className="route-indicator"><span className="status-dot" />URL actual: <code>{location.pathname}{location.search}</code></div>
        <PageContent />
      </main>
      <footer>React Router · una guía breve para leer y cambiar la URL</footer>
    </div>
  );
}

function PageContent() {
  const location = useLocation();
  const path = location.pathname;
  if (path === '/') return <Home />;
  if (path.startsWith('/curso/')) return <ParamsExample />;
  if (path === '/ubicacion') return <LocationExample />;
  if (path === '/buscar') return <SearchParamsExample />;
  if (path === '/contexto') return <ContextExample />;
  if (path === '/efecto') return <EffectExample />;
  return <NotFound />;
}

function Home() {
  return (
    <section className="hero-section">
      <p className="eyebrow">React Router / hooks</p>
      <h1>La URL también<br /><em>guarda estado.</em></h1>
      <p className="hero-copy">Explora hooks para convertir rutas, parámetros y búsquedas en datos que tu interfaz puede entender.</p>
      <div className="example-grid">
        <Link className="example-card coral" to="/curso/react"><span className="card-number">01</span><h2>useParams</h2><p>Lee valores dinámicos de una ruta, como el identificador de un curso.</p><span className="card-arrow">Ver ejemplo →</span></Link>
        <Link className="example-card blue" to="/ubicacion"><span className="card-number">02</span><h2>useLocation</h2><p>Observa pathname, search y state para saber dónde está tu usuario.</p><span className="card-arrow">Ver ejemplo →</span></Link>
        <Link className="example-card yellow" to="/buscar?q=hooks"><span className="card-number">03</span><h2>useSearchParams</h2><p>Sincroniza filtros y búsquedas con los parámetros de consulta.</p><span className="card-arrow">Ver ejemplo →</span></Link>
        <Link className="example-card green" to="/contexto"><span className="card-number">04</span><h2>useContext</h2><p>Comparte un valor entre componentes sin pasarlo manualmente por cada nivel.</p><span className="card-arrow">Ver ejemplo →</span></Link>
        <Link className="example-card violet" to="/efecto"><span className="card-number">05</span><h2>useEffect</h2><p>Ejecuta una tarea cuando cambian los datos que necesita.</p><span className="card-arrow">Ver ejemplo →</span></Link>
      </div>
    </section>
  );
}

function ParamsExample() {
  const { cursoId } = useParams();
  return <ExamplePage label="Ejemplo 01" title="useParams" accent="coral"><p className="intro">Extrae segmentos variables definidos en la ruta. Aquí, <code>:cursoId</code> cambia sin crear un componente nuevo.</p><div className="code-panel"><span className="code-comment">{'// URL: /curso/react'}</span><br /><span className="code-keyword">const</span> {'{ cursoId }'} = <span className="code-function">useParams</span>();</div><div className="result-box"><span>cursoId recibido</span><strong>{cursoId}</strong><small>El componente recibe este valor desde la URL.</small></div><div className="route-options"><span>Prueba otra ruta:</span><Link to="/curso/javascript">javascript</Link><Link to="/curso/react-router">react-router</Link></div></ExamplePage>;
}

function LocationExample() {
  const location = useLocation();
  return <ExamplePage label="Ejemplo 02" title="useLocation" accent="blue"><p className="intro">Devuelve el objeto que describe la ubicación actual. Es útil para menús activos, analítica o reaccionar a cambios de navegación.</p><div className="location-grid"><DataItem label="pathname" value={location.pathname} /><DataItem label="search" value={location.search || '(vacío)'} /><DataItem label="hash" value={location.hash || '(vacío)'} /><DataItem label="state" value={location.state ? JSON.stringify(location.state) : '(vacío)'} /></div><Link className="action-link" to="/ubicacion?desde=menu#detalle">Cambiar la URL y observar →</Link></ExamplePage>;
}

function SearchParamsExample() {
  const [searchParams, setSearchParams] = useSearchParams();
  const currentQuery = searchParams.get('q') || '';
  function handleSubmit(event) { event.preventDefault(); const query = new FormData(event.currentTarget).get('query').trim(); setSearchParams(query ? { q: query } : {}); }
  return <ExamplePage label="Ejemplo 03 · recomendado" title="useSearchParams" accent="yellow"><p className="intro">Un hook especialmente práctico para filtros: mantiene el valor de un formulario en una URL que se puede compartir.</p><form className="search-form" onSubmit={handleSubmit}><label htmlFor="query">Buscar en la URL</label><div className="input-row"><input id="query" name="query" defaultValue={currentQuery} placeholder="Escribe un concepto" /><button type="submit">Actualizar</button></div></form><div className="result-box"><span>parámetro q</span><strong>{currentQuery || '(sin búsqueda)'}</strong><small>Comparte esta dirección y el filtro viajará con ella.</small></div></ExamplePage>;
}

function ContextExample() {
  const [compact, setCompact] = useState(false);
  return <ReaderContext.Provider value={{ compact, toggle: () => setCompact(!compact) }}><ExamplePage label="Ejemplo 04" title="useContext" accent="green"><p className="intro">Lee valores compartidos por un proveedor sin recibirlos como props. Activa el modo compacto y el componente hijo reaccionará al mismo contexto.</p><ContextPanel /></ExamplePage></ReaderContext.Provider>;
}

function ContextPanel() {
  const { compact, toggle } = useContext(ReaderContext);
  return <div className={`context-panel ${compact ? 'compact' : ''}`}><span>Valor compartido: <strong>{compact ? 'compacto' : 'cómodo'}</strong></span><button type="button" onClick={toggle}>Cambiar modo</button></div>;
}

function EffectExample() {
  const [visits, setVisits] = useState(0);
  useEffect(() => {
    document.title = `useEffect · ${visits} visitas`;
    return () => { document.title = 'Hooks en ruta'; };
  }, [visits]);
  return <ExamplePage label="Ejemplo 05" title="useEffect" accent="violet"><p className="intro">Sincroniza el componente con algo externo. Cada clic actualiza el título de la pestaña y demuestra que el efecto depende de <code>visits</code>.</p><div className="effect-panel"><span>Visitas registradas</span><strong>{visits}</strong><button type="button" onClick={() => setVisits(visits + 1)}>Registrar visita</button></div></ExamplePage>;
}

function ExamplePage({ label, title, accent, children }) { return <section className={`example-page ${accent}`}><Link className="back-link" to="/">← Volver al mapa</Link><p className="eyebrow">{label}</p><h1>{title}</h1>{children}</section>; }
function DataItem({ label, value }) { return <div className="data-item"><span>{label}</span><code>{value}</code></div>; }
function NotFound() { return <ExamplePage label="404" title="Ruta no encontrada"><p className="intro">Esta dirección todavía no tiene un ejemplo. Regresa al inicio para continuar.</p><Link className="action-link" to="/">Ir al inicio →</Link></ExamplePage>; }

export default App;
