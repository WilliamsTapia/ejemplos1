import React from 'react';
import { Card, ListGroup, Badge, Button } from 'react-bootstrap';

const cartItems = [
  { id: 1, name: 'Camiseta', quantity: 1, price: 25000 },
  { id: 2, name: 'Pantalón', quantity: 2, price: 35000 },
  { id: 3, name: 'Zapatillas', quantity: 1, price: 90000 },
];

const ShoppingCart = () => {
  const total = cartItems.reduce(
    (sum, item) => sum + item.quantity * item.price,
    0
  );

  return (
    <Card className="shadow-sm">
      <Card.Header className="d-flex justify-content-between align-items-center">
        <h5 className="mb-0">Carrito de compras</h5>
        <Badge bg="primary">{cartItems.length} items</Badge>
      </Card.Header>

      <ListGroup variant="flush">
        {cartItems.map((item) => (
          <ListGroup.Item
            key={item.id}
            className="d-flex justify-content-between align-items-center"
          >
            <div>
              <strong>{item.name}</strong>
              <div className="text-muted small">
                {item.quantity} x ${item.price.toLocaleString('es-CL')}
              </div>
            </div>
            <span>${(item.quantity * item.price).toLocaleString('es-CL')}</span>
          </ListGroup.Item>
        ))}
      </ListGroup>

      <Card.Body>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <strong>Total:</strong>
          <strong>${total.toLocaleString('es-CL')}</strong>
        </div>

        <Button variant="success" className="w-100">
          Comprar ahora
        </Button>
      </Card.Body>
    </Card>
  );
};

export default ShoppingCart;
