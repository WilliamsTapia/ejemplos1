import React from 'react';
import { Card, Button, Row, Col } from 'react-bootstrap';

const products = [
  { id: 1, name: 'Camiseta', price: 25000, description: 'Camiseta casual de algodón' },
  { id: 2, name: 'Pantalón', price: 35000, description: 'Pantalón cómodo para diario' },
  { id: 3, name: 'Zapatillas', price: 90000, description: 'Zapatillas modernas y resistentes' },
  { id: 4, name: 'Gorra', price: 18000, description: 'Accesorio para uso diario' },
];

const ProductList = () => {
  return (
    <div>
      <h2 className="mb-3">Lista de Productos</h2>

      <Row className="g-3">
        {products.map((product) => (
          <Col md={6} key={product.id}>
            <Card className="h-100 shadow-sm">
              <Card.Body>
                <Card.Title>{product.name}</Card.Title>
                <Card.Text>{product.description}</Card.Text>
                <h5 className="text-primary">${product.price.toLocaleString('es-CL')}</h5>
                <Button variant="primary">Agregar al carrito</Button>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default ProductList;
