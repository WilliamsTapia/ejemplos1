import { render, screen } from '@testing-library/react';
import App from './App';

test('renders home page by default', () => {
  window.history.pushState({}, '', '/');
  render(<App />);

  expect(screen.getByText(/mi tienda/i)).toBeInTheDocument();
});

test('renders graphics page when the route changes', () => {
  window.history.pushState({}, '', '/graficos');
  render(<App />);

  expect(screen.getByText(/dashboard de ventas/i)).toBeInTheDocument();
});
