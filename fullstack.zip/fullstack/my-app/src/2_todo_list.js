import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {

  // Estado que almacena las tareas
  const [tareas, setTareas] = useState([]);

  // Estado del input
  const [nuevaTarea, setNuevaTarea] = useState("");

  // Agregar tarea
  const agregarTarea = () => {

    if (nuevaTarea.trim() === "") {
      return;
    }

    const tarea = {
      id: Date.now(),
      texto: nuevaTarea
    };

    setTareas([...tareas, tarea]);

    setNuevaTarea("");
  };


  // Eliminar tarea
  const eliminarTarea = (id) => {

    const nuevasTareas = tareas.filter(
      tarea => tarea.id !== id
    );

    setTareas(nuevasTareas);
  };


  return (

    <div className="container mt-5">

      <div className="row justify-content-center">

        <div className="col-md-8">

          <div className="card shadow">

            <div className="card-header bg-primary text-white">

              <h2 className="mb-0">
                Mi Todo List
              </h2>

            </div>


            <div className="card-body">

              {/* INPUT */}

              <div className="input-group mb-4">

                <input
                  type="text"
                  className="form-control"
                  placeholder="Escribe una tarea..."
                  value={nuevaTarea}
                  onChange={(e) =>
                    setNuevaTarea(e.target.value)
                  }
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      agregarTarea();
                    }
                  }}
                />

                <button
                  className="btn btn-success"
                  onClick={agregarTarea}
                >
                  Agregar
                </button>

              </div>


              {/* LISTA DE TAREAS */}

              {tareas.length === 0 ? (

                <div className="alert alert-info text-center">
                  No hay tareas pendientes
                </div>

              ) : (

                <ul className="list-group">

                  {tareas.map((tarea) => (

                    <li
                      key={tarea.id}
                      className="list-group-item d-flex justify-content-between align-items-center"
                    >

                      <span>
                        {tarea.texto}
                      </span>

                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() =>
                          eliminarTarea(tarea.id)
                        }
                      >
                        Eliminar
                      </button>

                    </li>

                  ))}

                </ul>

              )}

            </div>


            <div className="card-footer text-muted">

              Total de tareas: {tareas.length}

            </div>

          </div>

        </div>

      </div>

    </div>

  );
}

export default App;