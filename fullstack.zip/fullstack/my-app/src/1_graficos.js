//npm install bootstrap chart.js react-chartjs-2

import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
} from "chart.js";

import { Bar, Pie } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

function App() {

  // =========================
  // GRÁFICO DE BARRAS
  // =========================

  const datosBarras = {
    labels: ["Enero", "Febrero", "Marzo", "Abril", "Mayo"],

    datasets: [
      {
        label: "Ventas",

        data: [120, 190, 150, 250, 220],

        backgroundColor: [
          "rgba(54, 162, 235, 0.7)",
          "rgba(255, 99, 132, 0.7)",
          "rgba(255, 206, 86, 0.7)",
          "rgba(75, 192, 192, 0.7)",
          "rgba(153, 102, 255, 0.7)"
        ],

        borderColor: [
          "rgb(54, 162, 235)",
          "rgb(255, 99, 132)",
          "rgb(255, 206, 86)",
          "rgb(75, 192, 192)",
          "rgb(153, 102, 255)"
        ],

        borderWidth: 2
      }
    ]
  };


  // =========================
  // GRÁFICO DE TORTA
  // =========================

  const datosTorta = {
    labels: [
      "Tecnología",
      "Alimentos",
      "Viajes",
      "Ropa"
    ],

    datasets: [
      {
        label: "Ventas",

        data: [35, 30, 20, 15],

        backgroundColor: [
          "rgba(54, 162, 235, 0.8)",
          "rgba(255, 99, 132, 0.8)",
          "rgba(255, 206, 86, 0.8)",
          "rgba(75, 192, 192, 0.8)"
        ],

        borderColor: [
          "rgb(54, 162, 235)",
          "rgb(255, 99, 132)",
          "rgb(255, 206, 86)",
          "rgb(75, 192, 192)"
        ],

        borderWidth: 2
      }
    ]
  };


  return (
    <div className="container mt-5">

      <h1 className="text-center mb-5">
        Dashboard de Ventas
      </h1>

      <div className="row">

        {/* GRÁFICO DE BARRAS */}

        <div className="col-md-7 mb-4">

          <div className="card shadow">

            <div className="card-header bg-primary text-white">
              <h4 className="mb-0">
                Ventas por mes
              </h4>
            </div>

            <div className="card-body">

              <Bar data={datosBarras} />

            </div>

          </div>

        </div>


        {/* GRÁFICO DE TORTA */}

        <div className="col-md-5 mb-4">

          <div className="card shadow">

            <div className="card-header bg-dark text-white">
              <h4 className="mb-0">
                Ventas por categoría
              </h4>
            </div>

            <div className="card-body">

              <Pie data={datosTorta} />

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default App;