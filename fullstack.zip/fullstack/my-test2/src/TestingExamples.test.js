import { render, screen } from '@testing-library/react';
import { fetchData } from './testing-examples/api';
import DataPanel from './testing-examples/DataPanel';
import LazyPanel from './testing-examples/LazyPanel';
import UnitMessage from './testing-examples/UnitMessage';
import { measureRender } from './testing-examples/measureRender';

jest.mock('./testing-examples/api');

beforeEach(() => {
  jest.clearAllMocks();
});

test('06: renderiza un componente y encuentra el texto esperado', () => {
  render(<UnitMessage />);

  expect(screen.getByText('Texto esperado')).toBeInTheDocument();
});

test('05: carga el componente diferido', async () => {
  render(<LazyPanel />);

  expect(await screen.findByRole('heading', {
    name: 'Contenido cargado de forma diferida',
  })).toBeInTheDocument();
});

test('07: muestra los datos de una API simulada', async () => {
  fetchData.mockResolvedValue({ id: 1, name: 'Test' });
  render(<DataPanel />);

  expect(screen.getByRole('status')).toHaveTextContent('Cargando datos...');
  expect(await screen.findByText('Usuario: Test')).toBeInTheDocument();
  expect(fetchData).toHaveBeenCalledTimes(1);
});

test('07: muestra un error cuando falla la API simulada', async () => {
  fetchData.mockRejectedValue(new Error('Network error'));
  render(<DataPanel />);

  expect(await screen.findByRole('alert'))
    .toHaveTextContent('No se pudieron cargar los datos.');
});

test('09: mide el renderizado con un reloj controlado', () => {
  const now = jest.fn()
    .mockReturnValueOnce(10)
    .mockReturnValueOnce(13);
  const log = jest.spyOn(console, 'log').mockImplementation(() => {});

  const duration = measureRender(<UnitMessage />, now);

  expect(duration).toBe(3);
  expect(log).toHaveBeenCalledWith('Tiempo de renderizado: 3 ms');
});