export async function fetchData() {
  return { id: 1, name: 'Test' };
}