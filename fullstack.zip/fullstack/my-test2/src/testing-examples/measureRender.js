import { render } from '@testing-library/react';

export function measureRender(component, now = () => window.performance.now()) {
  const start = now();
  render(component);
  const duration = now() - start;
  console.log(`Tiempo de renderizado: ${duration} ms`);
  return duration;
}