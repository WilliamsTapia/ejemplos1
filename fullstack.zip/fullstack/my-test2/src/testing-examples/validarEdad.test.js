import { validarEdad } from './validarEdad';

test('clasifica a una persona adulta', () => {
  expect(validarEdad(20)).toBe('Mayor de edad');
});