import { useEffect, useState } from 'react';
import { fetchData } from './api';

function DataPanel() {
  const [state, setState] = useState({ status: 'loading', data: null });

  useEffect(() => {
    let isMounted = true;

    fetchData().then(
      (data) => {
        if (isMounted) setState({ status: 'success', data });
      },
      () => {
        if (isMounted) setState({ status: 'error', data: null });
      },
    );

    return () => {
      isMounted = false;
    };
  }, []);

  if (state.status === 'loading') return <p role="status">Cargando datos...</p>;
  if (state.status === 'error') return <p role="alert">No se pudieron cargar los datos.</p>;

  return <p>Usuario: {state.data.name}</p>;
}

export default DataPanel;