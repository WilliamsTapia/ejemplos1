function UnitMessage() {
  return <p>Texto esperado</p>;
}

export default UnitMessage;