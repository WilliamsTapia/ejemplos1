function LazyContent() {
  return <h2>Contenido cargado de forma diferida</h2>;
}

export default LazyContent;