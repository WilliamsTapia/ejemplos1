import { lazy, Suspense } from 'react';

const LazyContent = lazy(() => import('./LazyContent'));

function LazyPanel() {
  return (
    <Suspense fallback={<p role="status">Cargando ejemplo...</p>}>
      <LazyContent />
    </Suspense>
  );
}

export default LazyPanel;