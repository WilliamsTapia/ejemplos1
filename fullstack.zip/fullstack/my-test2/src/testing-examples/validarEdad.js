export function validarEdad(edad) {
  if (edad >= 18) {
    return 'Mayor de edad';
  } else {
    return 'Menor de edad';
  }
}