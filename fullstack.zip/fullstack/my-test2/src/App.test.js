import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe, toHaveNoViolations } from 'jest-axe';
import App from './App';

expect.extend(toHaveNoViolations);

test('muestra la guía de pruebas', () => {
  render(<App />);
  expect(screen.getByRole('heading', { name: /pruebas que dan confianza/i })).toBeInTheDocument();
  expect(screen.getByRole('heading', { name: 'Herramientas de testeo' })).toBeInTheDocument();
});

test('completa el flujo de login', async () => {
  render(<App />);
  await userEvent.type(screen.getByLabelText('Usuario'), 'testuser');
  await userEvent.type(screen.getByLabelText('Contraseña'), 'password');
  await userEvent.click(screen.getByRole('button', { name: 'Iniciar sesión' }));
  expect(await screen.findByText('Bienvenido, testuser')).toBeInTheDocument();
});

test('mantiene una entrada XSS como texto', async () => {
  const { container } = render(<App />);
  const payload = '<script>alert("XSS")</script>';
  const input = screen.getByRole('textbox', { name: 'Texto de prueba' });
  await userEvent.type(input, payload);
  expect(input).toHaveValue(payload);
  expect(container.querySelector('script')).toBeNull();
});

test('no tiene violaciones comunes de accesibilidad', async () => {
  const { container } = render(<App />);
  const results = await axe(container);
  expect(results).toHaveNoViolations();
});
