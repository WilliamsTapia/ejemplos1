import { useState } from 'react';
import './App.css';

const lessons = [
  { id: 'instalacion', number: '04', title: 'Herramientas de testeo' },
  { id: 'optimizacion', number: '05', title: 'Carga optimizada' },
  { id: 'unitarias', number: '06', title: 'Pruebas unitarias' },
  { id: 'mocking', number: '07', title: 'Mocking de dependencias' },
  { id: 'integracion', number: '08', title: 'Pruebas de integración' },
  { id: 'rendimiento', number: '09', title: 'Rendimiento' },
  { id: 'xss', number: '10', title: 'Inyección de código' },
  { id: 'accesibilidad', number: '11', title: 'Accesibilidad' },
  { id: 'jest-aws', number: '12', title: 'Jest en AWS' },
  { id: 'buildspec', number: '13', title: 'Pipeline de build' },
  { id: 'logging', number: '14', title: 'Logging' },
];

function CodeBlock({ children }) {
  return (
    <pre className="code-block">
      <code>{children}</code>
    </pre>
  );
}

function LoginDemo() {
  const [welcome, setWelcome] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setWelcome(`Bienvenido, ${formData.get('usuario')}`);
  }

  return (
    <form className="demo-form" onSubmit={handleSubmit}>
      <label htmlFor="usuario">Usuario</label>
      <input id="usuario" name="usuario" autoComplete="username" required />
      <label htmlFor="contrasena">Contraseña</label>
      <input
        id="contrasena"
        name="contrasena"
        type="password"
        autoComplete="current-password"
        required
      />
      <button className="action-button" type="submit">Iniciar sesión</button>
      <p className="demo-result" aria-live="polite">{welcome}</p>
    </form>
  );
}

function XssDemo() {
  const [value, setValue] = useState('');

  return (
    <div className="demo-form">
      <label htmlFor="xss-input">Texto de prueba</label>
      <input
        id="xss-input"
        value={value}
        onChange={(event) => setValue(event.target.value)}
      />
      <p className="demo-result" aria-live="polite">
        Entrada tratada como texto: <output>{value}</output>
      </p>
    </div>
  );
}

function App() {
  return (
    <div className="page-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="QA Lab, inicio">
          <span className="brand-mark">Q</span>
          <span>QA<span className="brand-light">/LAB</span></span>
        </a>
        <div className="topbar-meta"><span className="status-dot" /> GUÍA DE PRUEBAS <span className="topbar-divider">/</span> REACT</div>
        <a className="topbar-link" href="#integracion">Ver demostración <span aria-hidden="true">↘</span></a>
      </header>

      <div className="layout">
        <aside className="sidebar" aria-label="Contenido de la guía">
          <p className="sidebar-label">CONTENIDO</p>
          <nav>
            {lessons.map((lesson) => (
              <a key={lesson.id} href={`#${lesson.id}`}>
                <span>{lesson.number}</span>{lesson.title}
              </a>
            ))}
          </nav>
          <div className="sidebar-note">
            <span className="note-rule" />
            <p>Calidad desde el primer commit.</p>
            <span>EDICIÓN 2026</span>
          </div>
        </aside>

        <main id="inicio" className="content">
          <section className="intro">
            <p className="eyebrow"><span>PLAYBOOK</span> <span className="eyebrow-line" /> 11 PRÁCTICAS</p>
            <h1>Pruebas que dan<br /><em>confianza.</em></h1>
            <div className="intro-bottom">
              <p>Una guía práctica para probar interfaces React, detectar regresiones y preparar cada cambio para producción.</p>
              <a className="round-link" href="#instalacion" aria-label="Ir a herramientas de testeo">↓</a>
            </div>
            <div className="intro-index"><span>04—14</span><span>TESTING / FRONTEND</span></div>
          </section>

          <section className="lesson" id="instalacion">
            <div className="lesson-heading"><span className="lesson-number">04</span><div><p className="eyebrow">BASE DEL PROYECTO</p><h2>Herramientas de testeo</h2></div></div>
            <p className="lesson-copy">Testing Library y Jest ya están instalados en este proyecto mediante Create React App. Para añadir las comprobaciones de accesibilidad de esta guía, instala:</p>
            <CodeBlock>{'npm install --save-dev jest-axe'}</CodeBlock>
            <p className="micro-note"><span className="tiny-check">✓</span> Ya disponibles: Jest, React Testing Library, jest-dom y user-event.</p>
          </section>

          <section className="lesson" id="optimizacion">
            <div className="lesson-heading"><span className="lesson-number">05</span><div><p className="eyebrow">CARGA BAJO DEMANDA</p><h2>Componente optimizado</h2></div></div>
            <p className="lesson-copy">`lazy` divide el bundle y descarga el componente cuando se necesita. `Suspense` mantiene una respuesta visible durante la carga.</p>
            <CodeBlock>{`import { lazy, Suspense } from 'react';

const LazyComponent = lazy(() => import('./LazyComponent'));

function OptimizedApp() {
  return (
    <Suspense fallback={<div role="status">Cargando...</div>}>
      <LazyComponent />
    </Suspense>
  );
}`}</CodeBlock>
          </section>

          <section className="lesson" id="unitarias">
            <div className="lesson-heading"><span className="lesson-number">06</span><div><p className="eyebrow">UNIDAD PEQUEÑA, SEÑAL CLARA</p><h2>Pruebas unitarias</h2></div></div>
            <p className="lesson-copy">Comprueba lo que ve y percibe la persona que usa el componente, en lugar de sus detalles internos.</p>
            <CodeBlock>{`import { render, screen } from '@testing-library/react';
import MiComponente from './MiComponente';

test('renderiza el componente correctamente', () => {
  render(<MiComponente />);
  expect(screen.getByText('Texto esperado'))
    .toBeInTheDocument();
});`}</CodeBlock>
          </section>

          <section className="lesson" id="mocking">
            <div className="lesson-heading"><span className="lesson-number">07</span><div><p className="eyebrow">AISLAR LA DEPENDENCIA</p><h2>Mocking de dependencias</h2></div></div>
            <p className="lesson-copy">Simula respuestas de red para probar estados de carga, éxito y error sin depender de un servicio externo.</p>
            <CodeBlock>{`jest.mock('./api');
import { fetchData } from './api';

test('maneja la carga de datos', async () => {
  fetchData.mockResolvedValue({ id: 1, name: 'Test' });
  // Renderiza el consumidor y verifica el resultado.
});`}</CodeBlock>
          </section>

          <section className="lesson" id="integracion">
            <div className="lesson-heading"><span className="lesson-number">08</span><div><p className="eyebrow">UN FLUJO DE PRINCIPIO A FIN</p><h2>Prueba de integración</h2></div></div>
            <p className="lesson-copy">Interactúa con el formulario como una persona real. Este ejemplo se puede probar en el panel:</p>
            <div className="demo-panel">
              <div className="demo-panel-head"><span>DEMO INTERACTIVA</span><span className="demo-live"><i /> LISTA</span></div>
              <LoginDemo />
            </div>
            <CodeBlock>{`import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';

test('completa el flujo de login', async () => {
  render(<App />);
  await userEvent.type(screen.getByLabelText('Usuario'), 'testuser');
  await userEvent.type(screen.getByLabelText('Contraseña'), 'password');
  await userEvent.click(screen.getByRole('button', { name: 'Iniciar sesión' }));
  expect(await screen.findByText('Bienvenido, testuser'))
    .toBeInTheDocument();
});`}</CodeBlock>
          </section>

          <section className="lesson" id="rendimiento">
            <div className="lesson-heading"><span className="lesson-number">09</span><div><p className="eyebrow">MEDIR ANTES DE OPTIMIZAR</p><h2>Rendimiento</h2></div></div>
            <p className="lesson-copy">En el navegador, usa la API Performance. Una medición aislada sirve como orientación; para comparar builds, repite las pruebas en un entorno controlado.</p>
            <CodeBlock>{`import { render } from '@testing-library/react';

function medirRendimiento(componente) {
  const inicio = window.performance.now();
  render(componente);
  const fin = window.performance.now();
  console.log(\`Tiempo de renderizado: \${fin - inicio} ms\`);
}`}</CodeBlock>
          </section>

          <section className="lesson" id="xss">
            <div className="lesson-heading"><span className="lesson-number">10</span><div><p className="eyebrow">ENTRADA NO CONFIABLE</p><h2>Inyección de código</h2></div></div>
            <p className="lesson-copy">React muestra el valor interpolado como texto. No uses `dangerouslySetInnerHTML` con datos sin sanear. Prueba el campo aquí:</p>
            <div className="demo-panel"><div className="demo-panel-head"><span>CAMPO DE PRUEBA</span><span className="demo-live"><i /> TEXTO SEGURO</span></div><XssDemo /></div>
            <CodeBlock>{`test('trata la entrada como texto, no como HTML', async () => {
  const { container } = render(<Input />);
  const payload = '<script>alert("XSS")</script>';
  await userEvent.type(screen.getByRole('textbox'), payload);
  expect(screen.getByRole('textbox')).toHaveValue(payload);
  expect(container.querySelector('script')).toBeNull();
});`}</CodeBlock>
          </section>

          <section className="lesson" id="accesibilidad">
            <div className="lesson-heading"><span className="lesson-number">11</span><div><p className="eyebrow">INCLUIR DESDE EL INICIO</p><h2>Accesibilidad</h2></div></div>
            <p className="lesson-copy">Axe detecta problemas comunes automáticamente. Combínalo con pruebas manuales de teclado y lector de pantalla.</p>
            <CodeBlock>{`import { axe, toHaveNoViolations } from 'jest-axe';
expect.extend(toHaveNoViolations);

test('no tiene violaciones de accesibilidad', async () => {
  const { container } = render(<App />);
  expect(await axe(container)).toHaveNoViolations();
});`}</CodeBlock>
          </section>

          <section className="lesson" id="jest-aws">
            <div className="lesson-heading"><span className="lesson-number">12</span><div><p className="eyebrow">RECURSOS LIMITADOS</p><h2>Jest en AWS t2.micro</h2></div></div>
            <p className="lesson-copy">Limita los workers en Jest independiente. Create React App administra la configuración de Jest; en este proyecto pasa el límite desde el comando.</p>
            <CodeBlock>{`// Jest independiente: jest.config.js
module.exports = {
  maxWorkers: 2,
  maxConcurrency: 1,
};`}</CodeBlock>
            <p className="lesson-copy">En Create React App, ejecuta los tests con un máximo de dos workers:</p>
            <CodeBlock>{'npm test -- --watchAll=false --maxWorkers=2'}</CodeBlock>
          </section>

          <section className="lesson" id="buildspec">
            <div className="lesson-heading"><span className="lesson-number">13</span><div><p className="eyebrow">INTEGRACIÓN CONTINUA</p><h2>Buildspec para CodeBuild</h2></div></div>
            <p className="lesson-copy">Node 14 ya no recibe soporte. Usa un runtime mantenido y `npm ci` para instalaciones reproducibles desde el lockfile.</p>
            <CodeBlock>{`version: 0.2
phases:
  install:
    runtime-versions:
      nodejs: 20
    commands:
      - npm ci
  build:
    commands:
      - npm test -- --watchAll=false
      - npm run build
artifacts:
  files:
    - '**/*'
  base-directory: build`}</CodeBlock>
          </section>

          <section className="lesson" id="logging">
            <div className="lesson-heading"><span className="lesson-number">14</span><div><p className="eyebrow">OBSERVABILIDAD</p><h2>Logging efectivo</h2></div></div>
            <p className="lesson-copy">Winston es para Node.js, por ejemplo en un backend o proceso de build; no lo importes en el bundle del navegador.</p>
            <CodeBlock>{`const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({
      filename: 'error.log',
      level: 'error',
    }),
  ],
});`}</CodeBlock>
          </section>

          <footer className="footer"><span>QA/LAB <span className="footer-dot">•</span> PRÁCTICAS DE CALIDAD</span><a href="#inicio">VOLVER ARRIBA ↑</a></footer>
        </main>
      </div>
    </div>
  );
}

export default App;
