import { render, screen } from '@testing-library/react';
import App from './App';

test('renders the home route and navigation', () => {
  render(<App />);
  expect(screen.getByRole('heading', { name: /navega sin recargar/i })).toBeInTheDocument();
  expect(screen.getByRole('link', { name: 'Cursos' })).toBeInTheDocument();
});
