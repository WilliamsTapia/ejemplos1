import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import './App.css';

function Inicio() {
  return (
    <section className="page-card">
      <p className="eyebrow">React Router</p>
      <h1>Navega sin recargar la pagina</h1>
      <p>
        Este contenido cambia segun la URL gracias a las rutas de React Router.
        Prueba los enlaces del menu para ver el ejemplo.
      </p>
    </section>
  );
}

function Cursos() {
  return (
    <section className="page-card">
      <p className="eyebrow">Ruta: /cursos</p>
      <h1>Cursos disponibles</h1>
      <ul className="course-list">
        <li>React desde cero</li>
        <li>Interfaces con CSS</li>
        <li>Testing de componentes</li>
      </ul>
    </section>
  );
}

function Contacto() {
  return (
    <section className="page-card">
      <p className="eyebrow">Ruta: /contacto</p>
      <h1>Hablemos</h1>
      <p>Escribe a hola@ejemplo.dev para resolver tus dudas sobre React.</p>
    </section>
  );
}

function NoEncontrado() {
  return (
    <section className="page-card">
      <p className="eyebrow">Error 404</p>
      <h1>Pagina no encontrada</h1>
      <p>La ruta que buscas no existe.</p>
    </section>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <header className="site-header">
          <div>
            <p className="brand">Aula React</p>
            <span className="tagline">Ejemplo de navegacion</span>
          </div>
          <nav aria-label="Navegacion principal">
            <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
              Inicio
            </NavLink>
            <NavLink to="/cursos" className={({ isActive }) => (isActive ? 'active' : '')}>
              Cursos
            </NavLink>
            <NavLink to="/contacto" className={({ isActive }) => (isActive ? 'active' : '')}>
              Contacto
            </NavLink>
          </nav>
        </header>

        <main>
          <Routes>
            <Route path="/" element={<Inicio />} />
            <Route path="/cursos" element={<Cursos />} />
            <Route path="/contacto" element={<Contacto />} />
            <Route path="*" element={<NoEncontrado />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
