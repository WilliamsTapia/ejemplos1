import LoginPage from './pages/LoginPage';

function App() {
  return <LoginPage />;
}

export default App;

/*
import Input from "./components/atoms/Input";
import Button from "./components/atoms/Button";

function App() {
  return (
    <div>
      <h1>Formulario</h1>

      <Input
        label="Nombre"
        placeholder="Ingrese su nombre"
      />

      <Input
        label="Correo"
        type="email"
        placeholder="Ingrese su correo"
      />

      <Input
        label="Contraseña"
        type="password"
        placeholder="Ingrese su contraseña"
      />
      <Button type="submit">Ingresar</Button>
    </div>
  );
}

export default App;
 */