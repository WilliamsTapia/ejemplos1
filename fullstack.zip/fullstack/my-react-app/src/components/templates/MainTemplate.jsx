import Footer from '../organisms/Footer';
import Header from '../organisms/Header';
import Sidebar from '../organisms/Sidebar';

// Template: organiza los organismos y el contenido principal.
function MainTemplate({ children }) {
  return (
    <div className="app-layout">
      <Header />
      <div className="layout-body">
        <Sidebar />
        <main className="main-content">{children}</main>
      </div>
      <Footer />
    </div>
  );
}

export default MainTemplate;
