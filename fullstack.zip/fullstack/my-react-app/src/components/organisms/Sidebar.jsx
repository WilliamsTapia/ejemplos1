// Organismo: navegación lateral.
function Sidebar() {
  return (
    <aside className="sidebar">
      <p className="sidebar-title">Navegación</p>
      <nav aria-label="Menú lateral">
        <a className="sidebar-link sidebar-link--active" href="#inicio">Inicio</a>
        <a className="sidebar-link" href="#perfil">Perfil</a>
        <a className="sidebar-link" href="#configuracion">Configuración</a>
      </nav>
    </aside>
  );
}

export default Sidebar;
