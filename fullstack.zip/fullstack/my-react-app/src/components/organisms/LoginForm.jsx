import { useState } from 'react';
import Button from '../atoms/Button';
import FormField from '../molecules/FormField';

// Organismo: formulario compuesto por moléculas y átomos.
function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    console.log({ email, password });
  }

  return (
    <form className="login-form" onSubmit={handleSubmit}>
      <p className="form-eyebrow">Área privada</p>
      <h1>Iniciar sesión</h1>
      <p className="form-description">Ingresa tus datos para continuar a tu cuenta.</p>
      <FormField
        label="Correo electrónico"
        type="email"
        placeholder="tu@correo.com"
        value={email}
        onChange={(event) => setEmail(event.target.value)}
      />
      <FormField
        label="Contraseña"
        type="password"
        placeholder="Escribe tu contraseña"
        value={password}
        onChange={(event) => setPassword(event.target.value)}
      />
      <Button type="submit">Ingresar</Button>
    </form>
  );
}

export default LoginForm;
