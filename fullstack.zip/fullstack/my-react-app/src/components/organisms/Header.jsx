// Organismo: encabezado de la aplicación.
function Header() {
  return (
    <header className="header">
      <span className="brand-mark">M</span>
      <span>Mi Aplicación React</span>
    </header>
  );
}

export default Header;
