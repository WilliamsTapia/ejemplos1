// Organismo: pie de página.
function Footer() {
  return <footer className="footer">© 2026 Mi Aplicación React</footer>;
}

export default Footer;
