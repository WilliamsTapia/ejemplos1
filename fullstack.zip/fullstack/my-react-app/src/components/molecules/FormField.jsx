import Input from '../atoms/Input';
import Label from '../atoms/Label';

// Molécula: combina una etiqueta y un campo de entrada.
function FormField({ label, type, placeholder, value, onChange }) {
  return (
    <div className="form-field">
      <Label>{label}</Label>
      <Input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    </div>
  );
}

export default FormField;
