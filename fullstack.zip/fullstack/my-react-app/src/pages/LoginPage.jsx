import LoginForm from '../components/organisms/LoginForm';
import MainTemplate from '../components/templates/MainTemplate';

// Página: compone el template con el organismo del formulario.
function LoginPage() {
  return (
    <MainTemplate>
      <LoginForm />
    </MainTemplate>
  );
}

export default LoginPage;
